create view ttt as
SELECT
FROM it.employee;

alter table ttt
    owner to postgres;

