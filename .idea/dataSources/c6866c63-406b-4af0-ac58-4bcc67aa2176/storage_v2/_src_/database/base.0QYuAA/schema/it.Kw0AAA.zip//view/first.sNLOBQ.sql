create view first as
SELECT
FROM it.employee
WHERE employee.id > 0;

alter table first
    owner to postgres;

